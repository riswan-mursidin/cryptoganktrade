<?php  

require_once "../class/dbClass.php";
require_once "../class/getadmin.php";
require_once "../class/member.php";



session_start();
error_reporting(0)
?>