<?php  

require_once "class/dbClass.php";
require_once "class/getadmin.php";
require_once "class/member.php";
require_once "class/viewuser.php";

session_start();
error_reporting(0);
?>