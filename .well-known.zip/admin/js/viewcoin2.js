$(document).ready(function(){
    $("#wd").css('display','');
    $("#depo").css('display','none');
});


